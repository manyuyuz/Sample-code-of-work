%% normalization
function y = datachange(x)
flattenedData_X2 = x(:)'; %expand matrix by column and transpose it into one row
mappedflattened_X2 = mapminmax(flattenedData_X2,0.1,2);%normalization
norm_SENP1 = reshape(mappedflattened_X2, size(x));%revert into original matrix
y=norm_SENP1;
end