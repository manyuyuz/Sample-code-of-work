%% HIF1a level
X1 = [HIF1a.Data];
% norm_sumo_conjugation = (X4-min(X4))./(max(X4)-min(X4));
flattenedData_X1 = X1(:)'; %expand matrix by column and transpose it into one row
mappedflattened_X1 = mapminmax(flattenedData_X1,0.2,2);%normalization
norm_HIF1a = reshape(mappedflattened_X1, size(X1));%revert into original matrix