%% comparison of HIF1a level
x = [0, 2, 4, 6, 8];
% y1 = [0.55577715, 0.333069861, 0.626705332, 1.292148933, 2.732185476];
y1 = [0.391716464, 0.234990564, 0.442171068, 0.91170282, 1.927700459];
% xx = 0:0.01:4;
% yy = spline(x, y1, xx)
% plot(x,y1,'*',xx,yy,'r')
% yy = interp1 (x, y1, xx, 'spline cubic');
% plot(x, y1, 'g', xx, yy, 'linewidth', 0.5);
values1 = spcrv([[x(1) x x(end)]; [y1(1) y1 y1(end)]],3);
plot (values1(1,:),values1(2,:),'r')
hold on
% y2 = [0.1, 0.1004, 0.1969, 0.9736, 0.5263];%before applied GA
y2 = [0.2, 0.5029, 0.8038, 1.1067, 1.4092];
% xx = 0:0.01:4;
% yy = spline(x, y2, xx)
% plot(x,y2,'o',xx,yy,'g')
% yy = interp1 (x, y2, xx, 'spline cubic');
% plot(x, y2, 'r', xx, yy, 'linewidth', 0.5);
values1 = spcrv([[x(1) x x(end)]; [y2(1) y2 y2(end)]],3);
plot (values1(1,:),values1(2,:),'b')
xlabel('Time(h)')
ylabel('arbitrary scale')
title('Comparison of HIF1a level')
hold off


