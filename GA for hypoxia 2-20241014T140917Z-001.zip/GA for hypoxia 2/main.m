clear;
clc;
tStart = tic; 
popsize=10;%set population size


% targetvalue = [1.242165989;
%                0.573923639;
%                0.34658246;
%                1.143711215;
%                1.741629504;
%                1.197937165;
%                0.640817492];
% targetvalue = [0.265930518;
%                0.598270893;
%                0.623256543;
%                0.530231016;
%                0.508830694];%data for GA
% targetvalue = [0.65757286;
%                0.895519487; 
% %                1.08599615;
%                0.65996155;
%                0.56824915;
% %              1.010371042;
%                0.368145524];
% targetvalue = [1.52575769;
%                1.508400182;
%                1.556291889;
%                1.528901298;
%                1.424803507]; %literature data for SENP1
           
% targetvalue = [0.6;
%                0.62;
%                0.69;
%                0.76;
%                0.99;
%                0.56]; %exp3 data for SENP1
% targetvalue = [1.14;
%                1.06;
%                1.69;
%                0.77;
%                1.31;
%                1.21]; %exp2 data for SENP1
targetvalue = [1.41;
               2.17;
               2.19;
               2.74;
               1.26;
               1.41]; %exp2 data for SENP1
           
% targetvalue = [0.01950078;
%                1.228671294;
%                1.453851622;
%                1.516976952];
               
% targetvalue = [0;
%                0.573923639;
%                0.34658246;
%                1.143711215;
%                1.741629504;
%                1.197937165;
%                0.640817492];

% targetvalue = [0.4476;
%                0.4112;
%                0.5764;
%                1.3640;
%                0.4151;
%                1.8359;
%                1.9270];
           
% targetvalue = [0.6780;
%                0.8726;
%                1.0421;
%                1.0102;
%                0.5455;
%                0.8163;
%                0.9703];
% %            
% targetvalue = [0.391716464;
%                0.234990564;
%                0.442171068;
%                 0.91170282;
%                1.927700459;
%                0.850205289;
%                0.664985474]; %real data of HIF1alph

% targetvalue = [0; 
%                0.555177715;
%                0.333069861;
%                0.626705332;
%                1.292148933;
%                2.732185476;
%                1.205010973];  %real data of HIF1alph
%determine chromlength;
chromlength=44;
gbest = Inf;
%determine crossover rate
pc = 0.94;
%determine matutation rate
pm = 0.08;
%generate population 
pop = initpop(popsize,chromlength);
storebestpop = zeros(10, chromlength);
for j = 1:1000
    N = size(pop,1);
    finalpop = pop';
    for i = 1:N
        disp(i)
        d_s = finalpop(1,i);
        k1 = finalpop(2,i);
        k1d = finalpop(3,i);
        k2f = finalpop(4,i);
        k2r = finalpop(5,i);
        k3 = finalpop(6,i);
        k4f  = finalpop(7,i);
        k4r = finalpop(8,i);
        k4cat = finalpop(9,i);
        k5f = finalpop(10,i);
        k5r = finalpop(11,i);
        k5cat =finalpop(12,i);
        b_ps = finalpop(13,i);
        d_ps = finalpop(14,i);
        b_SENP = finalpop(15,i);
        d_E1 = finalpop(16,i);
        d_E2 =finalpop(17,i);
        d_se1 = finalpop(18,i);
        d_se2 = finalpop(19,i);
        d_SENP = finalpop(20,i);
        b_E1 = finalpop(21,i);
        b_E2 = finalpop(22,i);
        b_HIF1alph =finalpop(23,i);
        d_HIF1alph = finalpop(24,i);
        d_HIF1alphs = finalpop(25,i);
        k6 = finalpop(26,i);
        k7 = finalpop(27,i);
        k8 = finalpop(28,i);
        k9f = finalpop(29,i);
        k9r = finalpop(30,i);
        k9cat = finalpop(31,i);
        k10f = finalpop(32,i);
        k10r = finalpop(33,i);
        k11f = finalpop(34,i);
        k11r = finalpop(35,i);
        k12f = finalpop(36,i);
        k12r = finalpop(37,i);
        k13 = finalpop(38,i);
        k14f = finalpop(39,i);
        k14r = finalpop(40,i);
        k15f = finalpop(41,i);
        k15r = finalpop(42,i);
        b_E3 = finalpop(43,i);
        d_E3 = finalpop(44,i);
        out = sim('H:\My Drive\GA hypoxia\test.slx');
        tmp = out.SENP1.Data;%mathematical modelling data
        time = out.SENP1.Time;
%         tmp = HSF3p3.Data;%mathematical modelling data
%         time = HSF3p3.Time;
          B1=abs(time-0);
        [x,index1]=sort(B1);
        A1=[index1(1)];
        
        B2=abs(time-2);
        [x,index2]=sort(B2);
        A2=[index2(1)];
        
        B3=abs(time-4);
        [x,index3]=sort(B3);
        A3=[index3(1)];
        
        B4=abs(time-6);
        [x,index4]=sort(B4);
        A4=[index4(1)];
        
        B5=abs(time-8);
        [x,index5]=sort(B5);
        A5=[index5(1)];
        
        B6=abs(time-10);
        [x,index6]=sort(B6);
        A6=[index6(1)];
        
        tmp_N=[tmp(A1,1);
            tmp(A2,1);
            tmp(A3,1);
            tmp(A4,1);
            tmp(A5,1);
            tmp(A6,1)
            ];
            
        nor=datachange(tmp_N);
        re1 =datachange(tmp_N)-targetvalue; %error
        result(i) = sqrt(mean(re1.^2));%calculate root mean square error
    end
    objvalue = result;
    fitvalue = objvalue;
    %seclection operation
    newpop = selection(pop,fitvalue);
    %crossover operation
    newpop = crossover(newpop,pc);
    %mutation operation
    newpop = mutation(newpop,pm);
    %new population
    pop = newpop;
    %searching best result
    [storebestpop(j,:),bestfit] = best(pop,fitvalue);
    fprintf('iteration:%d   minValue :%.2f \n', j,bestfit);
    minFitness(j) = gbest;
    
    if bestfit < gbest
        gbest = bestfit;
        [minPos,~] = find(fitvalue==gbest,1, 'first');
        minFitness(j) = bestfit;
        bestindividual = pop(minPos, :);
    end
    
end
figure; 
plot(minFitness, 'MarkerFaceColor', 'black','LineWidth',1.5);
% title('Convege curve of SENP1 level root mean sqaure error');
ylabel('Fitness','FontWeight','bold','FontSize',15);
xlabel('Iteration','FontWeight','bold','FontSize',15);
set(gca,'linewidth',1.2)
grid on;
tEnd = toc(tStart);
fprintf('Time:%d minutes  %f seconds.\n', floor(tEnd/60), rem(tEnd,60));