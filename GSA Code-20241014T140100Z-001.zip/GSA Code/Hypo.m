function [S0,S0t,Si,Sti,Y1, f_time]=Hypo(N,PC)
tic;
PC = 1; % Mean percent change
N = 10000; % total run number
p = 29;   % Number of parameters
TS = 25; % State variables 
K1d = 0.0007;
K2f = 1.5478;
K2r = 0.0416;
K3f = 0.0226;
K4f = 0.4738;
K4r = 0.1392;
K4cat = 0.2144;
K5f = 0.72;
K5r = 0.56; %0.0242
K5cat = 10;%0.75
K6 = 0.00926;%0.926
K7 = 10.1;%0.101
K8f = 0.001;
K8r = 0.37;
K9 = 0.00034;
K10f = 0.1;
K10r = 33.1;
K10cat = 0.482;
K11f = 0.0148;
K11r = 0.6163;
K12f = 1.5478;
K12r = 0.0416;
K13 = 0.0026;
K14f = 0.0148;
K14r = 1.6733;
K15f = 0.2681;
K15r = 0.0809;
K16f = 0.2681;
K16r = 0.0809;
I10 = 1; %HIF1alpha
I20 = 1; %PHD
I30 = 0; %HIF1alpha:PHD
I40 = 0; %HIF1alpha_OH
I50 = 1; %VHL
I60 = 1; %presumo
I70 = 0; %SENP
I80 = 0; %presumo:SENP
I90 = 10; %sumo
I100 = 0; %E1
I110 = 0; %sumo:E1
I120 = 0.0001; %E2
I130 = 0; %sumo:E2
I140 = 0; %HIF1alpha:E3
I150 = 0; %HIF1alpha_s
I160 = 0; %HIF1alpha_s:SENP
I170 = 1; %HIF1beta
I180 = 0; %HIF1alpha:HIF1beta
I190 = 0; %HIF1alpha:HIF1beta:PHD
I200 = 0; %HIF1alpha_OH:HIF1beta
I210 = 0; %HRE
I220 = 0; %HIF1alpha:HIF1beta:HRE
I230 = 0; %HIF1alpha_OH:HIF1beta:HRE
I240 = 0; %HIF1alpha_OH:VHL
I250 = 0; %E3
x0 = [I10 I20 I30 I40 I50 I60 I70 I80 I90 I100 I110 I120 I130 I140 I150 I160 I170 I180 I190 I200 I210 I220 I230 I240 I250];
mt=7;
% t=linspace(0,mt,100);
% options = odeset('RelTol',1e-6,'AbsTol',1e-6);
t=0:mt;
lt=length(t)-1;
k1d=(K1d-K1d*(PC/100))+2*(PC/100)*K1d*lhsdesign(N,2);
k2f=(K2f-K2f*(PC/100))+2*(PC/100)*K2f*lhsdesign(N,2);
k2r=(K2r-K2r*(PC/100))+2*(PC/100)*K2r*lhsdesign(N,2); 
k3f=(K3f-K3f*(PC/100))+2*(PC/100)*K3f*lhsdesign(N,2); 
k4f=(K4f-K4f*(PC/100))+2*(PC/100)*K4f*lhsdesign(N,2);
k4r=(K4r-K4r*(PC/100))+2*(PC/100)*K4r*lhsdesign(N,2);
k4cat=(K4cat-K4cat*(PC/100))+2*(PC/100)*K4cat*lhsdesign(N,2);
k5f=(K5f-K5f*(PC/100))+2*(PC/100)*K5f*lhsdesign(N,2);
k5r=(K5r-K5r*(PC/100))+2*(PC/100)*K5r*lhsdesign(N,2);
k5cat=(K5cat-K5cat*(PC/100))+2*(PC/100)*K5cat*lhsdesign(N,2);
k6=(K6-K6*(PC/100))+2*(PC/100)*K6*lhsdesign(N,2); 
k7=(K7-K7*(PC/100))+2*(PC/100)*K7*lhsdesign(N,2); 
k8f=(K8f-K8f*(PC/100))+2*(PC/100)*K8f*lhsdesign(N,2);
k8r=(K8r-K8r*(PC/100))+2*(PC/100)*K8r*lhsdesign(N,2);
k9=(K9-K9*(PC/100))+2*(PC/100)*K9*lhsdesign(N,2);
k10f=(K10f-K10f*(PC/100))+2*(PC/100)*K10f*lhsdesign(N,2);
k10r=(K10r-K10r*(PC/100))+2*(PC/100)*K10r*lhsdesign(N,2);
k10cat=(K10cat-K10cat*(PC/100))+2*(PC/100)*K10cat*lhsdesign(N,2);
k11f=(K11f-K11f*(PC/100))+2*(PC/100)*K11f*lhsdesign(N,2); 
k11r=(K11r-K11r*(PC/100))+2*(PC/100)*K11r*lhsdesign(N,2); 
k12f=(K12f-K12f*(PC/100))+2*(PC/100)*K12f*lhsdesign(N,2);
k12r=(K12r-K12r*(PC/100))+2*(PC/100)*K12r*lhsdesign(N,2);
k13=(K13-K13*(PC/100))+2*(PC/100)*K13*lhsdesign(N,2);
k14f=(K14f-K14f*(PC/100))+2*(PC/100)*K14f*lhsdesign(N,2);
k14r=(K14r-K14r*(PC/100))+2*(PC/100)*K14r*lhsdesign(N,2); 
k15f=(K15f-K15f*(PC/100))+2*(PC/100)*K15f*lhsdesign(N,2); 
k15r=(K15r-K15r*(PC/100))+2*(PC/100)*K15r*lhsdesign(N,2); 
k16f=(K16f-K16f*(PC/100))+2*(PC/100)*K16f*lhsdesign(N,2);
k16r=(K16r-K16r*(PC/100))+2*(PC/100)*K16r*lhsdesign(N,2);

A = [k1d(:,1) k2f(:,1) k2r(:,1) k3f(:,1) k4f(:,1) k4r(:,1)...
    k4cat(:,1) k5f(:,1) k5r(:,1) k5cat(:,1) k6(:,1) k7(:,1)...
    k8f(:,1) k8r(:,1) k9(:,1) k10f(:,1) k10r(:,1) k10cat(:,1)...
    k11f(:,1) k11r(:,1) k12f(:,1) k12r(:,1) k13(:,1) k14f(:,1)...
    k14r(:,1) k15f(:,1) k15r(:,1) k16f(:,1) k16r(:,1)];
B = [k1d(:,2) k2f(:,2) k2r(:,2) k3f(:,2) k4f(:,2) k4r(:,2)...
    k4cat(:,2) k5f(:,2) k5r(:,2) k5cat(:,2) k6(:,2) k7(:,2) k8f(:,2)...
    k8r(:,2) k9(:,2) k10f(:,2) k10r(:,2) k10cat(:,2)...
    k11f(:,2) k11r(:,2) k12f(:,2) k12r(:,2) k13(:,2) k14f(:,2)...
    k14r(:,2) k15f(:,2) k15r(:,2) k16f(:,2) k16r(:,2)];
Y1=zeros(lt,TS,N);
Y2=zeros(lt,TS,N);
Y3=zeros(lt,TS,N);
S0 = zeros(lt,TS,p);
S0t = zeros(lt,TS,p);
Si=zeros(p,TS);
Sti=zeros(p,TS);
for i=1:N
    k1=[A(i,1) A(i,2) A(i,3) A(i,4) A(i,5) A(i,6) A(i,7) A(i,8)...
        A(i,9) A(i,10) A(i,11) A(i,12) A(i,13) A(i,14) A(i,15) A(i,16)...
        A(i,17) A(i,18) A(i,19) A(i,20) A(i,21) A(i,22) A(i,23) A(i,24)...
        A(i,25) A(i,26) A(i,27) A(i,28) A(i,29)];
    k2=[B(i,1) B(i,2) B(i,3) B(i,4) B(i,5) B(i,6) B(i,7) B(i,8)...
        B(i,9) B(i,10) B(i,11) B(i,12) B(i,13) B(i,14) B(i,15) B(i,16)...
        B(i,17) B(i,18) B(i,19) B(i,20) B(i,21) B(i,22) B(i,23) B(i,24)...
        B(i,25) B(i,26) B(i,27) B(i,28) B(i,29)];
    
    [t,x1]=ode45(@HypoModel,t,x0,[],k1);
    [t,x2]=ode45(@HypoModel,t,x0,[],k2);
    Y1(:,:,i) =x1(2:end,:);
    Y2(:,:,i) =x2(2:end,:);
    i
end
for r=1:p                  %Swaping ith colomn of A into ith colomn of B
    C = A;
    temp = B(:,r);
    C(:,r)=temp;
    for j=1:N
        k3=[C(j,1) C(j,2) C(j,3) C(j,4) C(j,5) C(j,6) C(j,7) C(j,8)...
            C(j,9) C(j,10) C(j,11) C(j,12) C(j,13) C(j,14) C(j,15) C(j,16)...
            C(j,17) C(j,18) C(j,19) C(j,20) C(j,21) C(j,22) C(j,23) C(j,24)...
            C(j,25) C(j,26) C(j,27) C(j,28) C(j,29)];
        [t,x3]=ode45(@HypoModel,t,x0,[],k3);
        Y3(:,:,j) = x3(2:end,:);
    end
    for s=1:TS        %solution
        for tt=1:lt              % time
            %% Si and Sti estimator offered by Jansen.
            %--------------------------------------------------------------
            % "Variance based sensitivity analysis of model output. Design
            % and estimator for the total sensitivity index. A, Saltelli"
            %--------------------------------------------------------------
            %% Mian effects,
            fi_j = (1/N*sum(squeeze(Y2(tt,s,:)))).^2;
            B_B = (squeeze(Y2(tt,s,:)).*squeeze(Y2(tt,s,:)));  % y2*y2
            Main_Var_j = sum(B_B)/N - fi_j;                    % variance
            B_C = (squeeze(Y2(tt,s,:))-squeeze(Y3(tt,s,:))).^2;
            S0(tt,s,r) = 1-sum(B_C)./(2*N*Main_Var_j);
            %% Total effects
            ft_j = (1/N*sum(squeeze(Y1(tt,s,:)))).^2;      % mean
            A_A = squeeze(Y1(tt,s,:)).*squeeze(Y1(tt,s,:));  % y1*y1
            Total_Var_j = sum(A_A)/N - ft_j;                    % variance
            A_C = (squeeze(Y1(tt,s,:))-squeeze(Y3(tt,s,:))).^2;
            S0t(tt,s,r) = sum(A_C)./(2*N*Total_Var_j);
        end
    end
    r
end
for i=1:p
for j=1:TS
    Si(i,j)=mean(abs(S0(:,j,i)));
    Sti(i,j)=mean(abs(S0t(:,j,i)));
end
f_time = toc;
end

disp(Si);
disp(Sti);
figure(1);
bar([Si(:,1) Sti(:,1)]);%HIF1alpha
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha}(t)','FontWeight','bold','FontSize',18)

figure(2);
bar([Si(:,2) Sti(:,2)]);%PHD
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for PHD(t)','FontWeight','bold','FontSize',18)

figure(3);
bar([Si(:,3) Sti(:,3)]);%HIF1alpha:PHD
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}PHD(t)','FontWeight','bold','FontSize',18)

figure(4);
bar([Si(:,4) Sti(:,4)]);%HIF1_OH
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}}(t)','FontWeight','bold','FontSize',18)

figure(5);
bar([Si(:,5) Sti(:,5)]);%VHL
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for VHL(t)','FontWeight','bold','FontSize',18)

figure(6);
bar([Si(:,6) Sti(:,6)]);%HIF1alpha_OH:VHL
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}\cdot}VHL(t)','FontWeight','bold','FontSize',18)

figure(7);
bar([Si(:,7) Sti(:,7)]);%presumo
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for presumo(t)','FontWeight','bold','FontSize',18)

figure(8);
bar([Si(:,8) Sti(:,8)]);%SENP
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for SENP(t)','FontWeight','bold','FontSize',18)

figure(9);
bar([Si(:,9) Sti(:,9)]);%presumo:SENP
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for presumo{\cdot}SENP(t)','FontWeight','bold','FontSize',18)

figure(10);
bar([Si(:,10) Sti(:,10)]);%sumo
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for sumo(t)','FontWeight','bold','FontSize',18)

figure(11);
bar([Si(:,11) Sti(:,11)]);%E1
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for E1(t)','FontWeight','bold','FontSize',18)

figure(12);
bar([Si(:,12) Sti(:,12)]);%sumo:E1
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for sumo{\cdot}E1(t)','FontWeight','bold','FontSize',18)

figure(13);
bar([Si(:,13) Sti(:,13)]);%E2
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for E2(t)','FontWeight','bold','FontSize',18)

figure(14);
bar([Si(:,14) Sti(:,14)]);%sumo:E2
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for sumo{\cdot}E2(t)','FontWeight','bold','FontSize',18)

figure(15);
bar([Si(:,15) Sti(:,15)]);%HIF1alpha:E3
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}E3(t)','FontWeight','bold','FontSize',18)

figure(16);
bar([Si(:,16) Sti(:,16)]);%HIF1alpha_s
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_s}(t)','FontWeight','bold','FontSize',18)

figure(17);
bar([Si(:,17) Sti(:,17)]);%HIF1alpha_s:SENP
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_s\cdot}SENP(t)','FontWeight','bold','FontSize',18)

figure(18);
bar([Si(:,18) Sti(:,18)]);%E3
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for E3(t)','FontWeight','bold','FontSize',18)

figure(19);
bar([Si(:,2) Sti(:,2)]);%HIF1beta
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\beta}(t)','FontWeight','bold','FontSize',18)

figure(20);
bar([Si(:,20) Sti(:,20)]);%HIF1alpha:HIF1beta
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}HIF1{\beta}(t)','FontWeight','bold','FontSize',18)

figure(21);
bar([Si(:,21) Sti(:,21)]);%HIF1alpha:HIF1beta:PHD
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}HIF1{\beta\cdot}PHD(t)','FontWeight','bold','FontSize',18)

figure(22);
bar([Si(:,22) Sti(:,22)]);%HIF1alpha_OH:HIF1beta
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}\cdot}HIF1{\beta}(t)','FontWeight','bold','FontSize',18)

figure(23);
bar([Si(:,23) Sti(:,23)]);%HRE
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HRE(t)','FontWeight','bold','FontSize',18)

figure(24);
bar([Si(:,24) Sti(:,24)]);%HIF1alpha:HIF1beta:PHD
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}HIF1{\beta\cdot}HRE(t)','FontWeight','bold','FontSize',18)

figure(25);
bar([Si(:,25) Sti(:,25)]);%HIF1alpha_OH:HIF1beta:PHD
ylim([0 1]);
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}\cdot}HIF1{\beta\cdot}HRE(t)','FontWeight','bold','FontSize',18)
function y=HypoModel(t,x,parameter)
k1d = parameter(1);
k2f = parameter(2);
k2r = parameter(3);
k3f = parameter(4);
k4f = parameter(5);
k4r = parameter(6);
k4cat = parameter(7);
k5f = parameter(8);
k5r = parameter(9);
k5cat = parameter(10);
k6 = parameter(11);
k7 = parameter(12);
k8f = parameter(13);
k8r = parameter(14);
k9 = parameter(15);
k10f = parameter(16);
k10r = parameter(17);
k10cat = parameter(18);
k11f = parameter(19);
k11r = parameter(20);
k12f = parameter(21);
k12r = parameter(22);
k13 = parameter(23);
k14f = parameter(24);
k14r = parameter(25);
k15f = parameter(26);
k15r = parameter(27);
k16f = parameter(28);
k16r = parameter(29);
y = zeros(25,1);
y(1)= -k1d*x(1)-k2f*x(1)*x(2)+k2r*x(3)-k11f*x(1)*x(17)+k11r*x(18)-k9*x(13)*x(1)+k10cat*x(16);%HIF1alpha
y(2) = -k2f*x(1)*x(2)+(k2r+k3f*0.001)*x(3)-k12f*x(18)*x(2)+(k12r+k13*0.001)*x(19);%PHD % set oxygen tension=0.1%
y(3) = k2f*x(1)*x(2)-(k2r+k3f*0.001)*x(3);%HIF1alpha:PHD %oxygen tension = 0.1%
y(4) = k3f*0.001*x(3)-k4f*x(4)*x(5)+k4r*x(24)-k14f*x(4)*x(17)+k14r*x(20);%HIF1alpha_OH %oxygen tension = 0.1%
y(5) = -k4f*x(4)*x(5)+(k4r+k4cat)*x(24);%VHL
y(6) = k4f*x(4)*x(5)-(k4r+k4cat)*x(24);%HIF1alpha_OH:VHL
y(7) = -k5f*x(6)*x(7)+k5r*x(8);%presumo
y(8) = -k5f*x(6)*x(7)+k5r*x(8)+k5cat*x(8)-k10f*x(15)*x(7)+k10r*x(16)+k10cat*x(16);%SENP
y(9) = k5f*x(6)*x(7)-k5r*x(8)-k5cat*x(8);%presumo:SENP
y(10) = k5cat*x(8)-k6*x(9)*x(10)+k10cat*x(16);%sumo %temperature 38:+(10*(1-0.4/10)*1.4*0.3)
y(11) = -k6*x(9)*x(10)+k7*x(11)*x(12);%E1
y(12) = k6*x(9)*x(10)-k7*x(11)*x(12);%sumo:E1
y(13) = k9*x(13)*x(14)-k7*x(11)*x(12);%E2
y(14) = k7*x(11)*x(12)-k9*x(13)*x(14);%sumo:E2
y(15) = k8f*x(1)*x(25)-k8r*x(14)-k9*x(13)*x(14);%HIF1alpha:E3
y(16) = k9*x(13)*x(14)-k10f*x(15)*x(7)+k10r*x(16);%HIF1alpha_s
y(17) = k10f*x(15)*x(7)-k10r*x(16)-k10cat*x(16);%HIF1alpha_s:SENP
y(18) = -k16f*x(1)*x(25)+k16r*x(14)+k6*x(14)*x(13);%E3
y(19) = -k11f*x(1)*x(17)+k11r*x(18)-k14f*x(4)*x(17)+k14r*x(20);%HIF1beta
y(20) = k11f*x(1)*x(17)-k11r*x(18)-k15f*x(18)*x(21)+k15r*x(22)-k12f*x(18)*x(2)+k12r*x(19);%HIF1alpha:HIF1beta
y(21) = k12f*x(18)*x(2)-(k12r+k13*0.005)*x(19);%HIF1alpha:HIF1beta:PHD
y(22) = k13*0.005*x(19)+k14f*x(4)*x(17)-k14r*x(20)-k16f*x(20)*x(21)+k16r*x(23);%HIF1alpha_OH:HIF1beta
y(23) = -k15f*x(18)*x(21)+k15r*x(22)-k16f*x(20)*x(21)+k16r*x(23);%HRE
y(24) = k15f*x(18)*x(21)-k15r*x(22);%HIF1alpha:HIF1beta:HRE
y(25) = k16f*x(20)*x(21)-k16r*x(23);%HIF1alpha_OH:HIF1beta:HRE
end
end

