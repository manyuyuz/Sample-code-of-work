function [S0,S0t,Si,Sti,Y1, f_time]=HS(N,PC)
tic;
PC = 1; % Mean percent change
N = 5000; % total run number
p = 24;          % Number of parameters:
TS = 19;         % State variables:
K1f = 0.42;
K1r = 0.005;
K2f = 0.42;
K2r = 0.005;
K3f = 0.023;
K3r = 0.00575;
Kmh = 0.4;
Km = 0.035;
K5f = 0.035;
K5r = 0.035;
K6f = 0.023;
K6r = 0.00036;
Kref = 0.014;
D2 = 0.013;
Kt = 0.035;
K7f = 0.72;
K7r = 0.0242;
K7cat = 0.75;
K8 = 0.926;
K9 = 0.101;
K10 = 0.52;
K11f = 0.1;
K11r = 33.1;
K11cat = 0.482;
I10 = 1; %DP
I20 = 1; %HSP
I30 = 0; %HSP:DP
I40 = 0; %HSP:HSF1
I50 = 1; %HSF1
I60 = 0; %HSF1_3
I70 = 0; %sumo:E2
I80 = 0; %SENP:HSF1_3s3
I90 = 0; %SENP
I100 = 0; %HSE:HSF1_3s3
I110 = 1; %HSE
I120 = 0; %mRNA
I130 = 10; %presumo
I140 = 0; %presumo:SENP
I150 = 1; %sumo
I160 = 1; %E1
I170 = 0; %sumo:E1
I180 = 1; %E2
I190 = 0; %HSF1_3s3
x0 = [I10 I20 I30 I40 I50 I60 I70 I80 I90 I100 I110 I120 I130 I140 I150 I160 I170 I180 I190];
mt = 7;
t = linspace(0,mt,100);
lt = length(t)-1;
k1f = (K1f-K1f*(PC/100))+2*(PC/100)*K1f*lhsdesign(N,2);
k1r = (K1r-K1r*(PC/100))+2*(PC/100)*K1r*lhsdesign(N,2);
k2f = (K2f-K2f*(PC/100))+2*(PC/100)*K2f*lhsdesign(N,2);
k2r = (K2r-K2r*(PC/100))+2*(PC/100)*K2r*lhsdesign(N,2);
k3f = (K3f-K3f*(PC/100))+2*(PC/100)*K3f*lhsdesign(N,2);
k3r = (K3r-K3r*(PC/100))+2*(PC/100)*K3r*lhsdesign(N,2);
kmh = (Kmh-Kmh*(PC/100))+2*(PC/100)*Kmh*lhsdesign(N,2);
km = (Km-Km*(PC/100))+2*(PC/100)*Km*lhsdesign(N,2);
k5f = (K5f-K5f*(PC/100))+2*(PC/100)*K5f*lhsdesign(N,2);
k5r = (K5r-K5r*(PC/100))+2*(PC/100)*K5r*lhsdesign(N,2);
k6f = (K6f-K6f*(PC/100))+2*(PC/100)*K6f*lhsdesign(N,2);
k6r = (K6r-K6r*(PC/100))+2*(PC/100)*K6r*lhsdesign(N,2);
kref = (Kref-Kref*(PC/100))+2*(PC/100)*Kref*lhsdesign(N,2);
d2 = (D2-D2*(PC/100))+2*(PC/100)*D2*lhsdesign(N,2);
kt = (Kt-Kt*(PC/100))+2*(PC/100)*Kt*lhsdesign(N,2);
k7f = (K7f-K7f*(PC/100))+2*(PC/100)*K7f*lhsdesign(N,2);
k7r = (K7r-K7r*(PC/100))+2*(PC/100)*K7r*lhsdesign(N,2);
k7cat = (K7cat-K7cat*(PC/100))+2*(PC/100)*K7cat*lhsdesign(N,2);
k8 = (K8-K8*(PC/100))+2*(PC/100)*K8*lhsdesign(N,2);
k9 = (K9-K9*(PC/100))+2*(PC/100)*K9*lhsdesign(N,2);
k10 = (K10-K10*(PC/100))+2*(PC/100)*K10*lhsdesign(N,2);
k11f = (K11f-K11f*(PC/100))+2*(PC/100)*K11f*lhsdesign(N,2);
k11r = (K11r-K11r*(PC/100))+2*(PC/100)*K11r*lhsdesign(N,2);
k11cat = (K11cat-K11cat*(PC/100))+2*(PC/100)*K11cat*lhsdesign(N,2);
A = [k1f(:,1) k1r(:,1) k2f(:,1) k2r(:,1) k3f(:,1) k3r(:,1) kmh(:,1)...
     km(:,1) k5f(:,1) k5r(:,1) k6f(:,1) k6r(:,1) kref(:,1) d2(:,1)...
     kt(:,1) k7f(:,1) k7r(:,1) k7cat(:,1) k8(:,1) k9(:,1) k10(:,1)...
     k11f(:,1) k11r(:,1) k11cat(:,1)];
 B = [k1f(:,2) k1r(:,2) k2f(:,2) k2r(:,2) k3f(:,2) k3r(:,2) kmh(:,2)...
     km(:,2) k5f(:,2) k5r(:,2) k6f(:,2) k6r(:,2) kref(:,2) d2(:,2)...
     kt(:,2) k7f(:,2) k7r(:,2) k7cat(:,2) k8(:,2) k9(:,2) k10(:,2)...
     k11f(:,2) k11r(:,2) k11cat(:,2)];
Y1=zeros(lt,TS,N);
Y2=zeros(lt,TS,N);
Y3=zeros(lt,TS,N);
S0 = zeros(lt,TS,p);
S0t = zeros(lt,TS,p);
Si=zeros(p,TS);
Sti=zeros(p,TS);
for i=1:N
    k1=[A(i,1) A(i,2) A(i,3) A(i,4) A(i,5) A(i,6) A(i,7) A(i,8) A(i,9)...
        A(i,10) A(i,11) A(i,12) A(i,13) A(i,14) A(i,15) A(i,16) A(i,17)...
        A(i,18) A(i,19) A(i,20) A(i,21) A(i,22) A(i,23) A(i,24)];
    k2=[B(i,1) B(i,2) B(i,3) B(i,4) B(i,5) B(i,6) B(i,7) B(i,8) B(i,9)...
        B(i,10) B(i,11) B(i,12) B(i,13) B(i,14) B(i,15) B(i,16) B(i,17)...
        B(i,18) B(i,19) B(i,20) B(i,21) B(i,22) B(i,23) B(i,24)];
    [t,x1]=ode45(@HSModel,t,x0,[],k1);
    [t,x2]=ode45(@HSModel,t,x0,[],k2);
    Y1(:,:,i) =x1(2:end,:);
    Y2(:,:,i) =x2(2:end,:);
    i
end
for r=1:p                  %Swaping ith colomn of A into ith colomn of B
    C = A;
    temp = B(:,r);
    C(:,r)=temp;
    for j=1:N
        k3=[C(j,1) C(j,2) C(j,3) C(j,4) C(j,5) C(j,6) C(j,7) C(j,8) C(j,9)...
            C(j,10) C(j,11) C(j,12) C(j,13) C(j,14) C(j,15) C(j,16) C(j,17)...
            C(j,18) C(j,19) C(j,20) C(j,21) C(j,22) C(j,23) C(j,24)];
        [t,x3]=ode45(@HSModel,t,x0,[],k3);
        Y3(:,:,j) = x3(2:end,:);
    end
    for s=1:TS        %solution
        for tt=1:lt              % time
            %% Si and Sti estimator offered by Jansen.
            %--------------------------------------------------------------
            % "Variance based sensitivity analysis of model output. Design
            % and estimator for the total sensitivity index. A, Saltelli"
            %--------------------------------------------------------------
            %% Mian effects,
            fi_j = (1/N*sum(squeeze(Y2(tt,s,:)))).^2;
            B_B = (squeeze(Y2(tt,s,:)).*squeeze(Y2(tt,s,:)));  % y2*y2
            Main_Var_j = sum(B_B)/N - fi_j;                    % variance
            B_C = (squeeze(Y2(tt,s,:))-squeeze(Y3(tt,s,:))).^2;
            S0(tt,s,r) = 1-sum(B_C)./(2*N*Main_Var_j);
            %% Total effects
            ft_j = (1/N*sum(squeeze(Y1(tt,s,:)))).^2;      % mean
            A_A = squeeze(Y1(tt,s,:)).*squeeze(Y1(tt,s,:));  % y1*y1
            Total_Var_j = sum(A_A)/N - ft_j;                    % variance
            A_C = (squeeze(Y1(tt,s,:))-squeeze(Y3(tt,s,:))).^2;
            S0t(tt,s,r) = sum(A_C)./(2*N*Total_Var_j);
        end
    end
    r
end
for i=1:p
for j=1:TS
    Si(i,j)=mean(abs(S0(:,j,i)));
    Sti(i,j)=mean(abs(S0t(:,j,i)));
end
f_time = toc;
end

disp(Si);
disp(Sti);
figure(1);
bar([Si(:,1) Sti(:,1)]);%DP
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for DP(t)','FontWeight','bold','FontSize',18)
figure(2);
bar([Si(:,2) Sti(:,2)]);%HSP:DP
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSP{\cdot}DP(t)','FontWeight','bold','FontSize',18)
figure(3);
bar([Si(:,3) Sti(:,3)]);%HSF1
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1(t)','FontWeight','bold','FontSize',18)
figure(4);
bar([Si(:,4) Sti(:,4)]);%HSP:HSF1
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSP{\cdot}HSF1(t)','FontWeight','bold','FontSize',18)

figure(5);
bar([Si(:,5) Sti(:,5)]);%HSF1_3
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1_3(t)','FontWeight','bold','FontSize',18)

figure(6);
bar([Si(:,6) Sti(:,6)]);%HSF1_3_s3
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1_3_s_3(t)','FontWeight','bold','FontSize',18)

figure(7);
bar([Si(:,7) Sti(:,7)]);%HSE
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSE(t)','FontWeight','bold','FontSize',18)

figure(8);
bar([Si(:,8) Sti(:,8)]);%HSE:HSF1_3_s3
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSE{\cdot}HSF1_3_s_3(t)','FontWeight','bold','FontSize',18)

figure(9);
bar([Si(:,9) Sti(:,9)]);%mRNA
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for mRNA(t)','FontWeight','bold','FontSize',18)

figure(10);
bar([Si(:,10) Sti(:,10)]);%HSP
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSP(t)','FontWeight','bold','FontSize',18)

figure(11);
bar([Si(:,11) Sti(:,11)]);%presumo
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for presumo(t)','FontWeight','bold','FontSize',18)

figure(12);
bar([Si(:,12) Sti(:,12)]);%SENP
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for SENP(t)','FontWeight','bold','FontSize',18)

figure(13);
bar([Si(:,13) Sti(:,13)]);%SENP:presumo
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for SENP{\cdot}presumo(t)','FontWeight','bold','FontSize',18)

figure(14);
bar([Si(:,14) Sti(:,14)]);%sumo
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for sumo(t)','FontWeight','bold','FontSize',18)

figure(15);
bar([Si(:,15) Sti(:,15)]);%E1
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for E1(t)','FontWeight','bold','FontSize',18)

figure(16);
bar([Si(:,16) Sti(:,16)]);%sumo:E1
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for sumo{\cdot}E1(t)','FontWeight','bold','FontSize',18)

figure(17);
bar([Si(:,17) Sti(:,17)]);%E2
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for E2(t)','FontWeight','bold','FontSize',18)

figure(18);
bar([Si(:,18) Sti(:,18)]);%sumo:E2
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for sumo{\cdot}E2(t)','FontWeight','bold','FontSize',18)

figure(19);
bar([Si(:,19) Sti(:,19)]);%SENP:HSF1_3_s3
ylim([0 1]);
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',18,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',18), 
ylabel('Sensitivity','FontWeight','bold','FontSize',18),
legend('Si','STi','FontWeight','bold','FontSize',20),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for SENP{\cdot}HSF1_3_s_3(t)','FontWeight','bold','FontSize',18)

      function y = HSModel (t,x,parameter)
        k1f = parameter(1);
        k1r = parameter(2);
        k2f = parameter(3);
        k2r = parameter(4);
        k3f = parameter(5);
        k3r = parameter(6);
        kmh = parameter(7);
        km = parameter(8);
        k5f = parameter(9);
        k5r = parameter(10);
        k6f = parameter(11);
        k6r = parameter(12);
        kref = parameter(13);
        d2 = parameter(14);
        kt = parameter(15);
        k7f = parameter(16);
        k7r = parameter(17);
        k7cat = parameter(18);
        k8 = parameter(19);
        k9 = parameter(20);
        k10 = parameter(21);
        k11f = parameter(22);
        k11r = parameter(23);
        k11cat = parameter(24);
        y = zeros(19,1);
        y(1) = -k1f*x(2)*x(1)+k1r*x(3)-k6f*x(4)*x(1)+k6r*x(3)*x(5);%DP %Temparature = 38
        y(2) = k1f*x(2)*x(1)-k1r*x(3)-kref*x(3)+k6f*x(4)*x(1)-k6r*x(3)*x(5);%HSP:DP
        y(3) = -k2f*x(2)*x(5)+k2r*x(4)-3*k3f*(x(5))^3+2*k3r*x(2)*x(6)+k6f*x(4)*x(1)-k6r*x(3)*x(5);%HSF1
        y(4) = k2f*x(2)*x(5)-k2r*x(4)-k6f*x(4)*x(1)+k6r*x(3)*x(5)+k3r*x(2)*x(6);%HSP:HSF1
        y(5) = k3f*(x(5))^3-k3r*x(2)*x(6)-k10*x(7)*x(6)+k11cat*x(8);%HSF1_3
        y(6) = k10*x(7)*x(6)-k11f*x(9)*x(19)+k11r*x(8)+k5r*x(10)-k5f*x(19)*x(11);%HSF1_3_s3
        y(7) = -k5f*x(19)*x(11)+k5r*x(10);%HSE
        y(8) = k5f*x(19)*x(11)-k5r*x(10);%HSF1_3_s3:HSE
        y(9) = kt*x(10)-km*x(12);%mRNA
        y(10) = kmh*x(12)-k2f*x(2)*x(5)+k2r*x(4)-k1f*x(2)*x(1)+k1r*x(3)-k3r*x(2)*x(6)+kref*x(3)-d2*x(2);%HSP
        y(11) = k7f*x(9)*x(13)-k7r*x(14);%presumo
        y(12) = -k7f*x(9)*x(13)+k7r*x(14)+k7cat*x(14)-k11f*x(9)*x(19)+k11r*x(8)+k11cat*x(8);%SENP
        y(13) = k7f*x(9)*x(13)-k7r*x(14)-k7cat*x(14);%presumo:SENP
        y(14) = k7cat*x(14)-k8*x(15)*x(16)+k11cat*x(8)+(10*(1-0.4/10)*1.4*0.3);%sumo %Temperature = 38
        y(15) = -k8*x(15)*x(16)+k9*x(17)*x(18);%E1
        y(16) = k8*x(15)*x(16)-k9*x(17)*x(18);%sumo:E1
        y(17) = -k9*x(17)*x(18)+k10*x(7)*x(6);%E2
        y(18) = k9*x(17)*x(18)-k10*x(7)*x(6);%sumo:E2
        y(19) = k11f*x(9)*x(19)-k11r*x(8)-k11cat*x(8);%SENP:HSF1_3_s3
      end
end
