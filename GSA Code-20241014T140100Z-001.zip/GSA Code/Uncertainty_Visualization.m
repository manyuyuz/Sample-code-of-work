%load('Smoke2_BgA_10000.mat')
figure;
Out = 3;
plot(squeeze(Y1(:,Out,:)),'g')
hold on;
plot(mean(squeeze(Y1(:,Out,:))'),'r','LineWidth',3)
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
%colorbar('FontWeight','bold','FontSize',20);
xlabel('Time [days]','FontWeight','bold','FontSize',24), 
ylabel('D(t)','FontWeight','bold','FontSize',24),
title('Parametric uncertainty in D(t) with N = 10000, parameter sets',...
    'FontWeight','bold','FontSize',24)