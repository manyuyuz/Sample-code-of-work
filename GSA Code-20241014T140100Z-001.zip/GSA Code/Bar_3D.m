Z = Si;
figure
h = bar3(Z,1);
%  set(gca,'XTickLabel',['P','S'])
%  set(gca,'YTickLabel','\mu')
set(gca,'fontsize',15,'FontWeight','bold')
colorbar('FontWeight','bold','FontSize',20);
xlabel('Output QoI','FontWeight','bold','FontSize',20), 
ylabel('Input QoI','FontWeight','bold','FontSize',20),
zlabel('S_{i}','FontWeight','bold','FontSize',20),
title('Parametric sensitivity in smoke model','FontWeight','bold','FontSize',30)
 for k = 1:length(h)
    zdata = get(h(k),'ZData');
    set(h(k),'CData',zdata,...
             'FaceColor','interp')
 end