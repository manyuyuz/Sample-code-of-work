% load('GSA_Corona_10000.mat')
K = 8;
TS = 5;
mat = 100.*Si';           %# A 5-by-5 matrix of random values from 0 to 1

imagesc(mat);            %# Create a colored plot of the matrix values
%figure;
% bar3(mat);
grid on;
%colormap(flipud(gray));  %# Change the colormap to gray (so higher values are
                         %#   black and lower values are white)

textStrings = num2str(mat(:),'%0.0f');  %# Create strings from the matrix values
textStrings = strtrim(cellstr(textStrings));  %# Remove any space padding
[x,y] = meshgrid(1:K, 1:TS);   %# Create x and y coordinates for the strings
hStrings = text(x(:),y(:),textStrings(:),...      %# Plot the strings
                'HorizontalAlignment','center', 'FontSize',14);
midValue = mean(0.00*get(gca,'CLim'));  %# Get the middle value of the color range
textColors = repmat(mat(:) > midValue,1,3);  %# Choose white or black for the
                                             %#   text color of the strings so
                                             %#   they can be easily seen over
                                             %#   the background color
set(hStrings,{'Color'},num2cell(textColors,2));  %# Change the text colors
title('Parametric sensitivity in smoke model',...
    'FontWeight','bold', 'FontSize',20);
xlabel({'Input QoI'},'FontWeight','bold',...
    'FontSize',20);

% Create ylabel
ylabel({'Output QoI'},'FontWeight','bold',...
    'FontSize',20);

% Create colorbar
colorbar('FontWeight','bold','FontSize',20);
%set(gca,'XTick',1:5,...                         %# Change the axes tick marks
%         'XTickLabel',{'A','B','C','D','E'},...  %#   and tick labels
%         'YTick',1:5,...
%         'YTickLabel',{'A','B','C','D','E'},...
%         'TickLength',[0 0]);