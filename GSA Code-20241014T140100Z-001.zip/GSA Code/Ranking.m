% Ranking
load('Smoke2_BgA_10000.mat')
L = {'\mu ';'\beta ';'\alpha ';'\gamma ';'\sigma '};
subplot(2,2,1); X = Si(:,1);
H = pie(X);
T = H(strcmpi(get(H,'Type'),'text'));
P = cell2mat(get(T,'Position'));
set(T,{'Position'},num2cell(P*0.6,2))
text(P(:,1),P(:,2),L(:))
grid on;
set(gca,'FontSize',20,'FontWeight','bold')
title('Ranking of parameters for P(t)','FontWeight','bold','FontSize',15)
subplot(2,2,2); X = Si(:,2);
H = pie(X);
T = H(strcmpi(get(H,'Type'),'text'));
P = cell2mat(get(T,'Position'));
set(T,{'Position'},num2cell(P*0.6,2))
text(P(:,1),P(:,2),L(:))
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
title('Ranking of parameters for S(t)','FontWeight','bold','FontSize',15)
subplot(2,2,3); X = Si(:,3);
H = pie(X);
T = H(strcmpi(get(H,'Type'),'text'));
P = cell2mat(get(T,'Position'));
set(T,{'Position'},num2cell(P*0.6,2))
text(P(:,1),P(:,2),L(:))
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
title('Ranking of parameters for Q_{t}(t)','FontWeight','bold','FontSize',15)
subplot(2,2,4); X = Si(:,4);
H = pie(X);
T = H(strcmpi(get(H,'Type'),'text'));
P = cell2mat(get(T,'Position'));
set(T,{'Position'},num2cell(P*0.6,2))
text(P(:,1),P(:,2),L(:))
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
title('Ranking of parameters for Q_{p}(t)','FontWeight','bold','FontSize',15)