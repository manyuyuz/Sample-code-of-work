% Interaction effects of parameters
bar([Si(:,1) Sti(:,1)]);%DP
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for DP(t)','FontWeight','bold','FontSize',15)

bar([Si(:,2) Sti(:,2)]);%HSP
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSP(t)','FontWeight','bold','FontSize',15)

bar([Si(:,3) Sti(:,3)]);%HSP:DP
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSP:DP(t)','FontWeight','bold','FontSize',15)

bar([Si(:,4) Sti(:,4)]);%HSP:HSF1
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSP:HSF1(t)','FontWeight','bold','FontSize',15)

bar([Si(:,5) Sti(:,5)]);%HSF1
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1(t)','FontWeight','bold','FontSize',15)

bar([Si(:,6) Sti(:,6)]);%HSF1_3
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1_3(t)','FontWeight','bold','FontSize',15)

bar([Si(:,7) Sti(:,7)]);%sumo:E2
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for sumo:E2(t)','FontWeight','bold','FontSize',15)

bar([Si(:,8) Sti(:,8)]);%SENP:HSF1_3_s3
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for SENP:HSF1_3_s3(t)','FontWeight','bold','FontSize',15)

bar([Si(:,9) Sti(:,9)]);%SENP
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for SENP(t)','FontWeight','bold','FontSize',15)

bar([Si(:,10) Sti(:,10)]);%HSF1_3_s3:HSE
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1_3_s3:HSE(t)','FontWeight','bold','FontSize',15)

bar([Si(:,11) Sti(:,11)]);%HSE
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSE(t)','FontWeight','bold','FontSize',15)

bar([Si(:,12) Sti(:,12)]);%mRNA
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for mRNA(t)','FontWeight','bold','FontSize',15)

bar([Si(:,13) Sti(:,13)]);%presumo
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for presumo(t)','FontWeight','bold','FontSize',15)

bar([Si(:,14) Sti(:,14)]);%presumo
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for presumo:SENP(t)','FontWeight','bold','FontSize',15)

bar([Si(:,15) Sti(:,15)]);%sumo
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for sumo(t)','FontWeight','bold','FontSize',15)

bar([Si(:,16) Sti(:,16)]);%E1
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for E1(t)','FontWeight','bold','FontSize',15)

bar([Si(:,17) Sti(:,17)]);%sumo:E1
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for sumo:E1(t)','FontWeight','bold','FontSize',15)

bar([Si(:,18) Sti(:,18)]);%E2
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for E2(t)','FontWeight','bold','FontSize',15)

bar([Si(:,19) Sti(:,19)]);%HSF1_3_s3
set(gca,'XTick',1:1:24);
set(gca,'XTicklabel',{'k1f','k1r','k2f','k2r','k3f','k3r','kmh','km','k5f',...
                      'k5r','k6f','k6r','kref','d2','kt','k7f','k7r','k7cat'...
                      'k8','k9','k10','k11f','k11r','k11cat'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt-order Sobol indices(Si) and total-order Sobol indices(STi) for HSF1_3_s3(t)','FontWeight','bold','FontSize',15)