% The process of transmission often occurs due to an initial inoculation 
% with a very small number of pathogen units (e.g., a few bacterial cells
% or virions). A period of time then ensues during which the pathogen 
% reproduces rapidly within the host, relatively unchallenged by the immune
% system. 
% Let N(t) be the population size at time, t which further decomposed into
% four subclasses; (i) susceptible population (S(t)), (ii) Exposed 
% individual (E(t)), infected population from corona (I(t)), recovered
% population from disease which are alive (R(t)) and death bodies due
% to corona (D(t)). 
% N(t) = S(t) + E(t) + I(t) + R(t) + D(t). We describe the dynamics of 
% corona by the following five nonlinear differential equations:
%
% dS/dt = Del - mu * S - alpha_e * S * E - alpha_i * S * I + gamma * R
% dE/dt = - (K + phi) * I + alpha_e * S * E + alpha_i * S * I
% dI/dt = -(beta + mu) I + K * E 
% dR/dt = - gamma * R + phi * E + beta * I
% dD/dt = mu * I

% del =  the migrated population into the considered community
% mu  =  the death rate due to corona of the infected population
% alpha_e = the contact rate between S(t) and E(t)
% alpha_i = the contact rate between S(t) and I(t)
% gamma = 
% K = the rate at which exposed population joined the infected class
% phi = the exposed population that directly goes to recovered class
% beta = the recovery rate, which recovered from disease and alive

% P(0) - initial proportion of the population that are potential smokers.
% S(0) - initial proportion of the population that are smokers.
% Qt(0) - initial proportion of the population who tem. quit smoking.
% Qp(t) - initial proportion of the population who perm. quit smoking.
%
% Requirements.
% All parameters must be positive, and S(0)+E(0)+I(0) < 1. 
%
% function call: [S0,S0t,Si,Sti, f_time, Y1]=Corona(N,PC)
% N - Total no. of model simulations per parameter.
function [S0,S0t,Si,Sti,Y1, f_time]=Corona(N,PC)
tic;
N =1000;
PC = 10;
p = 8;              % Number of parameters: del, mu, alpha_e, alpha_i,
                    % gamma, K, phi and beta
TS = 5;           % State variables: S(t), E(t), I(t), R(t) and D(t)
Del = 0;
Mu = 0.12;
Alpha_e = 0.3;
Alpha_i = 0.4;
Gamma = 0.23;
k = 0.3;
Phi = 0.25;
Beta = 0.45;
S0 = 100;
E0 = 10;
I0 = 3;
R0 = 0;
D0 = 0;
% Qp0=1-P0-S0-Qt0;
% if P0+L0+S0>1
% warning('Initial level of susceptibles+infecteds (%g+%g=%g) is greater than one',...
%         P0,S0,P0+S0);
% end
% 
% if Beta*Delta<(Gamma+Mu)*(Delta+Mu)
%     warning('Basic reproductive ratio (R_0=%g) is less than one',... 
%         Beta*Delta/((Gamma+Mu)*(Delta+Mu)));
% end
x0 = [S0 E0 I0 R0 D0];
mt=21;
t=linspace(0,mt,100);
%t=0:mt;
lt=length(t)-1;
del=(Del-Del*(PC/100))+2*(PC/100)*Del*lhsdesign(N,2);
mu=(Mu-Mu*(PC/100))+2*(PC/100)*Mu*lhsdesign(N,2);
alpha_e=(Alpha_e-Alpha_e*(PC/100))+2*(PC/100)*Alpha_e*lhsdesign(N,2); 
alpha_i=(Alpha_i-Alpha_i*(PC/100))+2*(PC/100)*Alpha_i*lhsdesign(N,2); 
gamma=(Gamma-Gamma*(PC/100))+2*(PC/100)*Gamma*lhsdesign(N,2);
K=(k-k*(PC/100))+2*(PC/100)*k*lhsdesign(N,2);
phi=(Phi-Phi*(PC/100))+2*(PC/100)*Phi*lhsdesign(N,2);
beta=(Beta-Beta*(PC/100))+2*(PC/100)*Beta*lhsdesign(N,2);
A=[del(:,1) mu(:,1) alpha_e(:,1) alpha_i(:,1) gamma(:,1) K(:,1)...
    phi(:,1) beta(:,1)];
B=[del(:,2) mu(:,2) alpha_e(:,2) alpha_i(:,2) gamma(:,2) K(:,2)...
    phi(:,2) beta(:,2)];
Y1=zeros(lt,TS,N);
Y2=zeros(lt,TS,N);
Y3=zeros(lt,TS,N);
S0 = zeros(lt,TS,p);
S0t = zeros(lt,TS,p);
Si=zeros(p,TS);
Sti=zeros(p,TS);
for i=1:N
    k1=[A(i,1) A(i,2) A(i,3) A(i,4) A(i,5) A(i,6) A(i,7) A(i,8)];
    k2=[B(i,1) B(i,2) B(i,3) B(i,4) B(i,5) B(i,6) B(i,7) B(i,8)];
    [t,x1]=ode45(@CoronaModel,t,x0,[],k1);
    [t,x2]=ode45(@CoronaModel,t,x0,[],k2);
    Y1(:,:,i) =x1(2:end,:);
    Y2(:,:,i) =x2(2:end,:);
    i
end
for r=1:p                  %Swaping ith colomn of A into ith colomn of B
    C = A;
    temp = B(:,r);
    C(:,r)=temp;
    for j=1:N
        k3=[C(j,1) C(j,2) C(j,3) C(j,4) C(j,5) C(j,6) C(j,7) C(j,8)];
        [t,x3]=ode45(@CoronaModel,t,x0,[],k3);
        Y3(:,:,j) = x3(2:end,:);
    end
    for s=1:TS        %solution
        for tt=1:lt              % time
            %% Si and Sti estimator offered by Jansen.
            %--------------------------------------------------------------
            % "Variance based sensitivity analysis of model output. Design
            % and estimator for the total sensitivity index. A, Saltelli"
            %--------------------------------------------------------------
            %% Mian effects,
            fi_j = (1/N*sum(squeeze(Y2(tt,s,:)))).^2;
            B_B = (squeeze(Y2(tt,s,:)).*squeeze(Y2(tt,s,:)));  % y2*y2
            Main_Var_j = sum(B_B)/N - fi_j;                    % variance
            B_C = (squeeze(Y2(tt,s,:))-squeeze(Y3(tt,s,:))).^2;
            S0(tt,s,r) = 1-sum(B_C)./(2*N*Main_Var_j);
            %% Total effects
            ft_j = (1/N*sum(squeeze(Y1(tt,s,:)))).^2;      % mean
            A_A = squeeze(Y1(tt,s,:)).*squeeze(Y1(tt,s,:));  % y1*y1
            Total_Var_j = sum(A_A)/N - ft_j;                    % variance
            A_C = (squeeze(Y1(tt,s,:))-squeeze(Y3(tt,s,:))).^2;
            S0t(tt,s,r) = sum(A_C)./(2*N*Total_Var_j);
        end
    end
    r
end
for i=1:p
for j=1:TS
    Si(i,j)=mean(abs(S0(:,j,i)));
    Sti(i,j)=mean(abs(S0t(:,j,i)));
end
f_time = toc;
end

bar([Si(:,1) Sti(:,1)])
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Main vs total sensitivity indices for P(t)','FontWeight','bold','FontSize',15)

    function y=CoronaModel(t,x,parameter)
        del = parameter(1);
        mu = parameter(2);
        alpha_e = parameter(3);
        alpha_i = parameter(4);
        gamma = parameter(5);
        K = parameter(6);
        phi = parameter(7);
        beta = parameter(8);
        y=zeros(5,1);
        y(1)= del- mu*x(1) -alpha_e*x(1)*x(2)-alpha_i*x(1)*x(3);
        y(2)= -(K + phi)*x(2) + alpha_e*x(1)*x(2) + alpha_i*x(1)*x(3);
        y(3)= -(beta + mu)*x(3) + K*x(2);
        y(4)= -gamma*x(4) + phi*x(2) + beta*x(3);
        y(5)= mu*x(3);       
    end
end