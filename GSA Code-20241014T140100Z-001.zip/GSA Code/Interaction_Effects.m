% Interaction effects of parameters
figure
subplot(3,2,1); bar([Si(:,1) Sti(:,1)])
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Main vs total sensitivity indices for P(t)','FontWeight','bold','FontSize',15)
subplot(3,2,2); bar([Si(:,2) Sti(:,2)])
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Main vs total sensitivity indices for S(t)','FontWeight','bold','FontSize',15)
subplot(3,2,3); bar([Si(:,3) Sti(:,3)])
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Main vs total sensitivity indices for Q_{t}(t)','FontWeight','bold','FontSize',15)
subplot(3,2,4); bar([Si(:,4) Sti(:,4)])
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Main vs total sensitivity indices for Q_{p}(t)','FontWeight','bold','FontSize',15)
subplot(3,2,5); bar([Si(:,5) Sti(:,5)])
grid on;
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Main vs total sensitivity indices for Q_{p}(t)','FontWeight','bold','FontSize',15)

% set(gca,'fontsize',15,'FontWeight','bold')
% %colorbar('FontWeight','bold','FontSize',20);
% xlabel('Time [months]','FontWeight','bold','FontSize',20), 
% ylabel('Q_{t}(t)','FontWeight','bold','FontSize',20),
% title('Solution of Q_{t}(t) with N = 10000','FontWeight','bold','FontSize',30)