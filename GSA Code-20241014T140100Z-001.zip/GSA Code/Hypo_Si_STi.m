figure(1);
bar([Si(:,1) Sti(:,1)]);%HIF1alpha
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha}(t)','FontWeight','bold','FontSize',15)

figure(2);
bar([Si(:,2) Sti(:,2)]);%PHD
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for PHD(t)','FontWeight','bold','FontSize',15)

figure(3);
bar([Si(:,3) Sti(:,3)]);%HIF1alpha_PHD
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}PHD(t)','FontWeight','bold','FontSize',15)

figure(4);
bar([Si(:,4) Sti(:,4)]);%HIF1_OH
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}}(t)','FontWeight','bold','FontSize',15)

figure(5);
bar([Si(:,5) Sti(:,5)]);%VHL
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for VHL(t)','FontWeight','bold','FontSize',15)

figure(6);
bar([Si(:,6) Sti(:,6)]);%HIF1alpha_OH:VHL
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}\cdot}VHL(t)','FontWeight','bold','FontSize',15)

figure(7);
bar([Si(:,7) Sti(:,7)]);%presumo
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for presumo(t)','FontWeight','bold','FontSize',15)

figure(8);
bar([Si(:,8) Sti(:,8)]);%PHD
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for SENP(t)','FontWeight','bold','FontSize',15)

figure(9);
bar([Si(:,9) Sti(:,9)]);%presumo_SENP
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for presumo{\cdot}SENP(t)','FontWeight','bold','FontSize',15)

figure(10);
bar([Si(:,10) Sti(:,10)]);%sumo
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for sumo(t)','FontWeight','bold','FontSize',15)

figure(11);
bar([Si(:,11) Sti(:,11)]);%E1
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for E1(t)','FontWeight','bold','FontSize',15)

figure(12);
bar([Si(:,12) Sti(:,12)]);%sumo_E1
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for sumo{\cdot}E1(t)','FontWeight','bold','FontSize',15)

figure(13);
bar([Si(:,13) Sti(:,13)]);%E2
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for E2(t)','FontWeight','bold','FontSize',15)

figure(14);
bar([Si(:,14) Sti(:,14)]);%sumo_E2
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for sumo{\cdot}E2(t)','FontWeight','bold','FontSize',15)

figure(15);
bar([Si(:,15) Sti(:,15)]);%HIF1alpha_E3
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}E3(t)','FontWeight','bold','FontSize',15)

figure(16);
bar([Si(:,16) Sti(:,16)]);%HIF1alpha_s
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_s}(t)','FontWeight','bold','FontSize',15)

figure(17);
bar([Si(:,17) Sti(:,17)]);%HIF1alpha_s:SENP
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_s\cdot}SENP(t)','FontWeight','bold','FontSize',15)

figure(18);
bar([Si(:,18) Sti(:,18)]);%E3
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for E3(t)','FontWeight','bold','FontSize',15)

figure(19);
bar([Si(:,2) Sti(:,2)]);%HIF1beta
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\beta}(t)','FontWeight','bold','FontSize',15)

figure(20);
bar([Si(:,20) Sti(:,20)]);%HIF1alpha_HIF1beta
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}HIF1{\beta}(t)','FontWeight','bold','FontSize',15)

figure(21);
bar([Si(:,21) Sti(:,21)]);%HIF1alpha:HIF1beta:PHD
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}HIF1{\beta\cdot}PHD(t)','FontWeight','bold','FontSize',15)

figure(22);
bar([Si(:,22) Sti(:,22)]);%HIF1alpha_OH:HIF1beta
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}\cdot}HIF1{\beta}(t)','FontWeight','bold','FontSize',15)

figure(23);
bar([Si(:,23) Sti(:,23)]);%HRE
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HRE(t)','FontWeight','bold','FontSize',15)

figure(24);
bar([Si(:,24) Sti(:,24)]);%HIF1alpha:HIF1beta:PHD
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha\cdot}HIF1{\beta\cdot}HRE(t)','FontWeight','bold','FontSize',15)

figure(25);
bar([Si(:,25) Sti(:,25)]);%HIF1alpha_OH:HIF1beta:PHD
set(gca,'XTick',1:1:29);
set(gca,'XTicklabel',{'k1d','k2f','k2r','k3','k4f','k4r','k4cat','k5f','k5r'...
                      'k5cat','k6','k7','k8f','k8r','k9','k10f','k10r','k10cat'...
                      'k11f','k11r','k12f','k12r','k13','k14f','k14r','k15f'...
                      'k15r','k16f','k16r'})
set(gca,'fontsize',15,'FontWeight','bold')
xlabel('Parameters','FontWeight','bold','FontSize',12), 
ylabel('Sensitivity','FontWeight','bold','FontSize',12),
title('Fisrt order Sobol indices(Si) and total order Sobol indices(STi) for HIF1{\alpha_{OH}\cdot}HIF1{\beta\cdot}HRE(t)','FontWeight','bold','FontSize',15)