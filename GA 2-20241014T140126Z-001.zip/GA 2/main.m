clear;
clc;
tStart = tic; 
popsize=10;%set population size

%experiment data of sumo conjugation
% targetvalue = [0.198317697;
% 1.370320399;
% 1.310446616;
% 1.109547065;
% 1.034547065;
% 1.004063865];%fake data of sumo conjugation

targetvalue = [0;
0.186486227;
1.175693823;
1.430305587;
1.196433296;
1.008138413];%real data of sumo conjugation

%experiment data of phosphorylated HSF3
% targetvalue = [0.1428247;
% 1.3159277;
% 1.7266053;
% 1.631601;
% 0.8462561;
% 0.2933087];

%determine chromlength;
chromlength=25;
gbest = Inf;
%determine crossover rate
pc = 0.94;
%determine matutation rate
pm = 0.08;
%generate population 
pop = initpop(popsize,chromlength);
storebestpop = zeros(10, chromlength);
for j = 1:10
    N = size(pop,1);
    finalpop = pop';
    for i = 1:N
        disp(i)
        d_s = finalpop(1,i);
        k6_f = finalpop(2,i);
        k6_r = finalpop(3,i);
        k7_f = finalpop(4,i);
        k7_r = finalpop(5,i);
        k7_cat = finalpop(6,i);
        k8  =finalpop(7,i);
        k9 = finalpop(8,i);
        k10 = finalpop(9,i);
        k11_f = finalpop(10,i);
        k11_r = finalpop(11,i);
        k11_cat =finalpop(12,i);
        b_ps = finalpop(13,i);
        d_ps = finalpop(14,i);
        b_SENP = finalpop(15,i);
        d_E1 = finalpop(16,i);
        d_E2 =finalpop(17,i);
        d_se1 = finalpop(18,i);
        d_se2 = finalpop(19,i);
        d_SENP = finalpop(20,i);
        b_E1 = finalpop(21,i);
        b_E2 = finalpop(22,i);
        b_HSF3p3 =finalpop(23,i);
        d_HSF3p3 = finalpop(24,i);
        d_HSF3p3s3 =finalpop(25,i);
        out = sim('C:\Users\uos\Dropbox\HS_GA\GA 2\HS.slx');
        tmp= sumo_c.Data;%mathematical modelling data
        time=sumo_c.Time;
%         tmp = HSF3p3.Data;%mathematical modelling data
%         time = HSF3p3.Time;
        B1=abs(time-0);
        [x,index1]=sort(B1);
        A1=[index1(1)];
        
        B2=abs(time-2);
        [x,index2]=sort(B2);
        A2=[index2(1)];
        
        B3=abs(time-4);
        [x,index3]=sort(B3);
        A3=[index3(1)];
        
        B4=abs(time-6);
        [x,index4]=sort(B4);
        A4=[index4(1)];
        
        B5=abs(time-8);
        [x,index5]=sort(B5);
        A5=[index5(1)];
        
        B6=abs(time-10);
        [x,index6]=sort(B6);
        A6=[index6(1)];
        
        tmp_N=[tmp(A1,1);
            tmp(A2,1);
            tmp(A3,1);
            tmp(A4,1);
            tmp(A5,1);
            tmp(A6,1);
            ];
        nor=datachange(tmp_N);
        re1 =datachange(tmp_N)-targetvalue;%error
        result(i) = sqrt(mean(re1.^2));%calculate root mean square error
    end
    objvalue = result;
    fitvalue = objvalue;
    %seclection operation
    newpop = selection(pop,fitvalue);
    %crossover operation
    newpop = crossover(newpop,pc);
    %mutation operation
    newpop = mutation(newpop,pm);
    %new population
    pop = newpop;
    %searching best result
    [storebestpop(j,:),bestfit] = best(pop,fitvalue);
    fprintf('iteration:%d   minValue :%.2f \n', j,bestfit);
    minFitness(j) = gbest;
    
    if bestfit < gbest
        gbest = bestfit;
        [minPos,~] = find(fitvalue==gbest,1, 'first');
        minFitness(j) = bestfit;
        bestindividual = pop(minPos, :);
    end
    
end
figure; 
plot(minFitness, 'MarkerFaceColor', 'red','LineWidth',1);
title('convege curve of mean sqaure error');
ylabel('fitness');
xlabel('iteration');
grid on;
tEnd = toc(tStart);
fprintf('Time:%d minutes  %f seconds.\n', floor(tEnd/60), rem(tEnd,60));