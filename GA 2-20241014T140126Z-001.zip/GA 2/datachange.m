%% normalization
function y = datachange(x)
flattenedData_X2 = x(:)'; %expand matrix by column and transpose it into one row
mappedflattened_X2 = mapminmax(flattenedData_X2,0.1,1);%normalization
norm_sumo_conjugation = reshape(mappedflattened_X2, size(x));%revert into original matrix
y=norm_sumo_conjugation;
end